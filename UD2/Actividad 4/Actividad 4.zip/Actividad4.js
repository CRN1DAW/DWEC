let num = prompt("Introduce un número");

if (isNaN(num)){
    alert("No es un número");
} else{
    alert("Es un número");
}